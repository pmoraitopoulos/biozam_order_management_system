package docentries;

public class Shipping extends Docentry {
	public Shipping(String date, int no, String abbreviation, FiscalYear fy) {
		super(date, no, abbreviation, fy);
		// TODO Auto-generated constructor stub
	}

	public Salesorder sales;
}