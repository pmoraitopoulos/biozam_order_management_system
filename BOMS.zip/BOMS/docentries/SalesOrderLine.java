package docentries;

import items.Jam;

public class SalesOrderLine extends DcLine {
	public Jam unnamed_Jam_;
}