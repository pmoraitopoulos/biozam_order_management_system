package docentries;

import items.Fruit;

public class PrpsOrderLines extends DcLine {
	public Fruit has_fruit;
}