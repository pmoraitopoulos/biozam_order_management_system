package docentries;

import items.Fruit;

public class ProductiityLine extends DcLine {
	public Fruit has_fruit;
}